﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChooseUrPC
{
    public class Grade:INotifyPropertyChanged
    {
        public double gradeorg = 3;
        public double Grade2
        {
            get { return this.gradeorg; }
            set
            {
                if (this.gradeorg != value)
                {
                    if (this.gradeorg < 0.1)
                        this.gradeorg = value + 0.1;
                    else if (this.gradeorg >4.9)
                        this.gradeorg = value - 0.1;
                    else
                        this.gradeorg = Math.Round(value, 2);

                    this.NotifyPropertyChanged("Grade2");

                }
            }

        }


        public event PropertyChangedEventHandler PropertyChanged;

        public void NotifyPropertyChanged(string PropertyName)
        {
            if (this.PropertyChanged != null)
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(PropertyName));
            }
        }
    }
}
