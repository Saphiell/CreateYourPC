﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Serialization;

namespace ChooseUrPC
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public ObservableCollection<PickElements> ElementsList { get; set; }
        public ObservableCollection<SearchElem> SearchList { get; set;}
        public Grade grade;

        public MainWindow()
        {
            InitializeComponent();
            this.DataContext = this;

            ElementsList = new ObservableCollection<PickElements>();
            SearchList = new ObservableCollection<SearchElem>(ElementsList);

            this.PCelementComboBox.ItemsSource = Enum.GetValues(typeof(PCelements));
            this.PCelementComboBox.SelectedIndex = 0;

            this.grade = new Grade();
            this.GradeTextBox.DataContext = grade;



        }
        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            double pickgrade = 3;
            try
            {


                string model = this.ModelTextBox.Text;
                double price = Math.Round(double.Parse(this.ValueofProduct.Text), 2);
                

                pickgrade = Convert.ToDouble(this.GradeTextBox.Text.Replace(".", ","));


                PCelements pcelement = (PCelements)Enum.Parse(typeof(PCelements), this.PCelementComboBox.Text);


                PickElements pickelem = new PickElements(pcelement, model, pickgrade, price);
                SearchElem searchelem = new SearchElem(pcelement, model, pickgrade, price);

                if (string.IsNullOrEmpty(model))
                {
                    MessageBox.Show("U can't add blank Model", "Model");
                }
                else
                {
                    ElementsList.Add(pickelem);
                    SearchList.Add(searchelem);
                }
            }
            catch (FormatException ex1)
            {

                MessageBox.Show("Price must be a number", "Cena");
            }


        }

        private void DelButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                this.ElementsList.RemoveAt(this.ElementsListView.SelectedIndex);
            }
            catch (Exception ex)
            {
                MessageBox.Show("First click on a character u want to delete.", "Delete character");
            }

        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.SaveFileDialog sejf = new Microsoft.Win32.SaveFileDialog();
            sejf.FileName = "Elements"; //domyślna nazwa pliku
            sejf.DefaultExt = ".xml"; // rozszerzenie domyślne pliku
            sejf.Filter = "XML documents (.xml)|*.xml"; // 

            Nullable<bool> result = sejf.ShowDialog();
            if (result == true)
            {
                string filePath = sejf.FileName;
                ListToXmlFile(filePath);
            }
        }

        private void ListToXmlFile(string filePath)
        {
            using (var sw = new StreamWriter(filePath)) //cos jak try -catch
            {
                var serializer = new XmlSerializer(typeof(ObservableCollection<PickElements>));
                serializer.Serialize(sw, ElementsList);
                
            }
        }
    
        private void LoadButton_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog sejf = new Microsoft.Win32.OpenFileDialog();
            sejf.FileName = "Elements"; //domyślna nazwa pliku
            sejf.DefaultExt = ".xml"; // rozszerzenie domyślne pliku
            sejf.Filter = "XML documents (.xml)|*.xml";

            Nullable<bool> result = sejf.ShowDialog();
            string filename = "";
            
            if (result == true)
            {

                filename = sejf.FileName;

            }
            if (File.Exists(filename))
            {
                XmlFileToList(filename);
                
            }
            else { MessageBox.Show(@"File doesn't exist"); }
        }

        private void XmlFileToList(string filename)
        {
            using (var sr = new StreamReader(filename))
            {
                var deserialization = new XmlSerializer(typeof(ObservableCollection<PickElements>));
                ObservableCollection<PickElements> tmpList = (ObservableCollection<PickElements>)deserialization.Deserialize(sr);
               
                foreach (var item in tmpList)
                {
                    ElementsList.Add(item);
                    
                }
               
            }
           
        }
        private void Plus_Click(object sender, RoutedEventArgs e)
        {

            grade.Grade2 += 0.1;

        }

        private void Minus_Click(object sender, RoutedEventArgs e)
        {
            grade.Grade2 -= 0.1;


        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
           
            
            double value= Convert.ToDouble(this.ValueTextBox.Text.Replace(".", ","));         
            double weightA = Convert.ToDouble(this.GraphTextBox.Text.Replace(".", ","));
            double weightB = Convert.ToDouble(this.MainTextBox.Text.Replace(".", ","));
            double weightC = Convert.ToDouble(this.ProcTextBox.Text.Replace(".", ","));
            double weightD = Convert.ToDouble(this.RamTextBox.Text.Replace(".", ","));
            if (weightA + weightB + weightC + weightD == 1)
            {
                foreach (var item in ElementsList)
                {

                    if (item.PCElement.Equals(PCelements.Karta_Graficzna) && item.Price < weightA * value)
                        SearchList.Add(item);
                    if (item.PCElement.Equals(PCelements.Plyta_Glowna) && item.Price < weightB * value)
                        SearchList.Add(item);
                    if (item.PCElement.Equals(PCelements.Ram) && item.Price < weightD * value)
                        SearchList.Add(item);
                    if (item.PCElement.Equals(PCelements.Procesor) && item.Price < weightC * value)
                        SearchList.Add(item);

                }
            }
            else
                MessageBox.Show("Prosze dobrać wagi tak by sumowały sie do 1");

                
                

            

                 
            
       }

        private void SaveSearchButton_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.SaveFileDialog sejf1 = new Microsoft.Win32.SaveFileDialog();
            sejf1.FileName = "Elements"; //domyślna nazwa pliku
            sejf1.DefaultExt = ".xml"; // rozszerzenie domyślne pliku
            sejf1.Filter = "XML documents (.xml)|*.xml"; // 

            Nullable<bool> result = sejf1.ShowDialog();
            if (result == true)
            {
                string filePath1 = sejf1.FileName;
                SaveListToXmlFile(filePath1);
            }
        }
        private void SaveListToXmlFile(string filePath1)
        {
            using (var sw = new StreamWriter(filePath1)) //cos jak try -catch
            {
                var serializer = new XmlSerializer(typeof(ObservableCollection<SearchElem>));
                serializer.Serialize(sw, SearchList);
                

            }
        }
    }
}
