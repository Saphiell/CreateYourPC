﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChooseUrPC
{
    public class SearchElem:FatherElements
    {
        public SearchElem() { }
        public SearchElem(PCelements spcelement, string smodel, double sgrade, double sprice)
        {
            this.Model = smodel;
            this.Grade = sgrade;
            this.Price = sprice;
            PCElement = spcelement;
        }
    }
}
