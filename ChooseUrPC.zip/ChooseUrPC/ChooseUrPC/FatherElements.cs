﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChooseUrPC
{
    public enum PCelements { Karta_Graficzna, Procesor, Ram, Plyta_Glowna}
    public class FatherElements
    {
        public string Model { get; set; }
        public double Price { get; set; }
        public double Grade { get; set; }

        public PCelements PCElement { get; set; }
    }
}
