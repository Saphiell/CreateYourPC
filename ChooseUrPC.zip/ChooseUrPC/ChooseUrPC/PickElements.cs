﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChooseUrPC
{
    public class PickElements:SearchElem
    {
        public PickElements() { }
        public PickElements(PCelements pcelement, string model, double grade, double price)
        {
            this.Model = model;
            this.Grade = grade;
            this.Price = price;
            PCElement = pcelement;
        }
    }
}
